from django.db import models


class Album(models.Model):
    Educator = models.CharField(max_length=100)
    Album_title = models.CharField(max_length=200)
    Genre = models.CharField(max_length=100)
    Album_logo = models.CharField(max_length=100)

    def __str__(self):
         return self.album_title + ' _ ' + self.Genre