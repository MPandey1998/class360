from django.http import HttpResponse


def index(request):
    return HttpResponse("his is the video page")
